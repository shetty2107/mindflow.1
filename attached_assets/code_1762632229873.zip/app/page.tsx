"use client"

import { Navbar } from "@/components/navbar"
import { CursorGradientText } from "@/components/cursor-gradient-text"
import { useEffect } from "react"

export default function HomePage() {
  useEffect(() => {
    const user = localStorage.getItem("mindflow_currentUser")
    if (user) {
      const logoutBtn = document.getElementById("logoutBtn")
      if (logoutBtn) logoutBtn.classList.remove("hidden")
    }
  }, [])

  return (
    <main>
      <Navbar />

      {/* Hero Section */}
      <section className="min-h-screen bg-gradient-to-b from-background to-card flex items-center justify-center px-4">
        <div className="max-w-4xl mx-auto text-center space-y-6 animate-slide-in-up">
          <div className="text-6xl md:text-7xl font-bold animate-float">🧠</div>
          <CursorGradientText className="text-4xl md:text-6xl font-bold leading-tight transition-colors duration-100">
            Your Brain. Your Way. Your Study.
          </CursorGradientText>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Personalized study plans that adapt to your mental health and energy levels using AI
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <a href="/login" className="btn-primary text-lg">
              Start Your Journey ✨
            </a>
            <a href="#features" className="btn-outline text-lg">
              Learn More
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-card">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 animate-slide-in-up">
            How MindFlow Helps You
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                icon: "📝",
                title: "Brain Dump",
                desc: "Overwhelmed? Type everything. AI breaks it into manageable steps.",
              },
              { icon: "⚡", title: "Energy Mapper", desc: "Schedule tasks during YOUR peak hours - morning or night." },
              { icon: "😊", title: "Emotion Tracker", desc: "Feeling anxious? We adapt your plan in real-time." },
              { icon: "🎉", title: "Progress Celebration", desc: "Complete tasks, earn streaks, see your growth." },
            ].map((feature, i) => (
              <div
                key={i}
                className="card-glow hover:translate-y-[-8px] animate-slide-in-up"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className="text-5xl mb-4">{feature.icon}</div>
                <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-background">
        <div className="max-w-3xl mx-auto text-center space-y-6 animate-slide-in-up">
          <h2 className="text-4xl md:text-5xl font-bold">Built with Care</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            We built MindFlow because we know what it's like to study with anxiety, procrastination, and overwhelm.
            While other apps force one-size-fits-all schedules, MindFlow uses AI to create plans that adapt to YOUR
            mental health, energy levels, and unique challenges. Every task is broken into dopamine-friendly steps.
            Every emotion gets a personalized response. Every completed task is celebrated.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-8 px-4 text-center text-muted-foreground">
        <p>&copy; 2025 MindFlow Team | Built for Students Who Deserve Better</p>
      </footer>
    </main>
  )
}
