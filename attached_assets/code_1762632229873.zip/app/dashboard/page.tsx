"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [selectedEmotion, setSelectedEmotion] = useState("")
  const [tasks, setTasks] = useState([
    { id: 1, title: "Review Chapter 1-3", duration: "1h", done: true },
    { id: 2, title: "Practice Problems Set A", duration: "45m", done: true },
    { id: 3, title: "Watch Lecture 4", duration: "1.5h", done: false },
    { id: 4, title: "Summarize Key Concepts", duration: "30m", done: false },
  ])

  useEffect(() => {
    const currentUser = localStorage.getItem("mindflow_currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(currentUser))
  }, [router])

  const handleTaskToggle = (id: number) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)))
  }

  const emotions = [
    { emoji: "😊", label: "Happy & Focused" },
    { emoji: "😐", label: "Normal" },
    { emoji: "😰", label: "Anxious" },
    { emoji: "😟", label: "Tired" },
    { emoji: "😤", label: "Frustrated" },
  ]

  const completedTasks = tasks.filter((t) => t.done).length
  const progressPercent = Math.round((completedTasks / tasks.length) * 100)

  if (!user) return null

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-card border-b border-border backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <div className="animate-slide-in-up">
              <h1 className="text-3xl font-bold">Hi, {user.name}! 👋</h1>
              <p className="text-muted-foreground">Let's crush your study goals today</p>
            </div>
            <button
              onClick={() => {
                localStorage.removeItem("mindflow_currentUser")
                router.push("/login")
              }}
              className="btn-secondary"
            >
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8 space-y-8">
        {/* Emotion Section */}
        <section className="animate-slide-in-up">
          <h2 className="text-2xl font-bold mb-4">How are you feeling right now?</h2>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {emotions.map((emotion) => (
              <button
                key={emotion.label}
                onClick={() => setSelectedEmotion(emotion.label)}
                className={`p-4 rounded-lg border-2 transition-all duration-300 ${
                  selectedEmotion === emotion.label
                    ? "border-primary bg-primary/10 scale-105"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <div className="text-3xl mb-2">{emotion.emoji}</div>
                <div className="text-xs font-medium text-center">{emotion.label}</div>
              </button>
            ))}
          </div>
          {selectedEmotion && (
            <div className="mt-4 p-4 bg-primary/10 border border-primary/30 rounded-lg animate-slide-in-up">
              <p className="text-sm font-medium">
                {selectedEmotion === "Happy & Focused" && "🎯 Great! Let's tackle those challenging tasks first."}
                {selectedEmotion === "Normal" && "✅ Perfect for steady, consistent progress."}
                {selectedEmotion === "Anxious" && "🧘 Take it slow - break tasks into smaller steps."}
                {selectedEmotion === "Tired" && "⚡ Let's do lighter tasks and take more breaks."}
                {selectedEmotion === "Frustrated" && "🎵 Step back and do something enjoyable first."}
              </p>
            </div>
          )}
        </section>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Today's Study Plan */}
            <section className="animate-slide-in-up" style={{ animationDelay: "100ms" }}>
              <h2 className="text-2xl font-bold mb-4">Today's Study Plan</h2>
              <div className="space-y-3">
                {tasks.map((task, i) => (
                  <div
                    key={task.id}
                    onClick={() => handleTaskToggle(task.id)}
                    className="card-glow cursor-pointer group flex items-center justify-between"
                    style={{ animationDelay: `${i * 50}ms` }}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <input
                        type="checkbox"
                        checked={task.done}
                        onChange={() => {}}
                        className="w-6 h-6 rounded-lg cursor-pointer accent-primary"
                      />
                      <div className={`transition-all ${task.done ? "line-through text-muted-foreground" : ""}`}>
                        <p className="font-semibold">{task.title}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium">
                        {task.duration}
                      </span>
                      {task.done && <span className="text-xl">✅</span>}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            {/* Progress */}
            <div className="card-glow animate-slide-in-up" style={{ animationDelay: "200ms" }}>
              <h3 className="font-bold mb-4">Today's Progress</h3>
              <div className="flex items-center justify-center mb-4">
                <div className="relative w-32 h-32">
                  <svg className="transform -rotate-90 w-32 h-32">
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      className="text-muted opacity-20"
                    />
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      fill="none"
                      stroke="url(#grad1)"
                      strokeWidth="8"
                      strokeDasharray={`${(2 * Math.PI * 56 * progressPercent) / 100} ${2 * Math.PI * 56}`}
                      className="transition-all duration-500"
                    />
                    <defs>
                      <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="var(--color-primary)" />
                        <stop offset="100%" stopColor="var(--color-secondary)" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-3xl font-bold">{progressPercent}%</p>
                      <p className="text-xs text-muted-foreground">Complete</p>
                    </div>
                  </div>
                </div>
              </div>
              <p className="text-center text-sm text-muted-foreground">
                {completedTasks} of {tasks.length} tasks done
              </p>
            </div>

            {/* Streak */}
            <div className="card-glow animate-slide-in-up" style={{ animationDelay: "300ms" }}>
              <h3 className="font-bold mb-3">Study Streak 🔥</h3>
              <p className="text-4xl font-bold text-primary mb-2">7</p>
              <p className="text-sm text-muted-foreground">Day Streak! Keep it up! 💪</p>
            </div>

            {/* Wellness Tip */}
            <div
              className="card-glow bg-gradient-to-br from-primary/10 to-secondary/10 animate-slide-in-up"
              style={{ animationDelay: "400ms" }}
            >
              <h3 className="font-bold mb-2">💡 Daily Tip</h3>
              <p className="text-sm">Pomodoro Technique: Study 25 min, break 5 min. Perfect for focus!</p>
            </div>
          </aside>
        </div>
      </div>
    </main>
  )
}
