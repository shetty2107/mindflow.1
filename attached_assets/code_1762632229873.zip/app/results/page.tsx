"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { FloatingObjects } from "@/components/floating-objects"

interface BrainDumpData {
  tasks: string
  deadline: string
  knowledge: string
  hours: string
  challenges: string[]
  subject: string
  customSubject: string
  energyTime: string
}

export default function ResultsPage() {
  const router = useRouter()
  const [planData, setPlanData] = useState<any>(null)
  const [brainDumpData, setBrainDumpData] = useState<BrainDumpData | null>(null)

  useEffect(() => {
    const data = localStorage.getItem("brainDumpData")
    if (!data) {
      router.push("/brain-dump")
      return
    }

    const parsed = JSON.parse(data) as BrainDumpData
    setBrainDumpData(parsed)

    // Generate plan based on input
    const generatedPlan = generatePlan(parsed)
    setPlanData(generatedPlan)
  }, [router])

  const generatePlan = (data: BrainDumpData) => {
    const hoursNum = Number.parseInt(data.hours)
    const taskCount = data.tasks.split(",").length
    const daysUntilDeadline = calculateDays(data.deadline)
    const tasksPerDay = Math.ceil(taskCount / Math.max(daysUntilDeadline, 1))
    const breakMinutes = Math.min(Math.ceil((hoursNum * 60) / 12), 30)

    return {
      totalTasks: taskCount,
      estimatedHours: ((hoursNum * daysUntilDeadline) / taskCount).toFixed(1),
      breakMinutes: breakMinutes,
      schedule: `Optimal schedule created for ${data.energyTime} person for ${data.subject || data.customSubject}`,
      dayPlans: tasksPerDay,
      knowledge: data.knowledge,
      challenges: data.challenges,
    }
  }

  const calculateDays = (deadline: string) => {
    if (!deadline) return 1
    const today = new Date()
    const deadlineDate = new Date(deadline)
    const diff = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    return Math.max(diff, 1)
  }

  if (!planData || !brainDumpData) return null

  return (
    <main>
      <FloatingObjects />
      <Navbar />

      <div className="min-h-screen pt-20 pb-12 px-4 flex items-center justify-center">
        <div className="max-w-2xl w-full">
          <div className="card-glow backdrop-blur-sm bg-gradient-to-br from-background/95 to-card/50 border border-border rounded-2xl p-8 md:p-12 animate-slide-in-up">
            {/* Title */}
            <div className="text-center mb-8">
              <div className="text-6xl mb-4 inline-block animate-bounce">🎉</div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent mb-2">
                Your Plan is Ready!
              </h1>
            </div>

            {/* Stats Grid */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {/* Total Tasks */}
              <div
                className="card-glow bg-card/50 border border-border rounded-xl p-6 text-center hover:scale-105 transition-transform duration-300 animate-slide-in-up"
                style={{ animationDelay: "100ms" }}
              >
                <div className="text-4xl font-bold text-primary mb-2">{planData.totalTasks}</div>
                <p className="text-muted-foreground font-medium">Total Tasks</p>
              </div>

              {/* Estimated Hours */}
              <div
                className="card-glow bg-card/50 border border-border rounded-xl p-6 text-center hover:scale-105 transition-transform duration-300 animate-slide-in-up"
                style={{ animationDelay: "150ms" }}
              >
                <div className="text-4xl font-bold text-purple-500 mb-2">{planData.estimatedHours}</div>
                <p className="text-muted-foreground font-medium">Estimated Hours</p>
              </div>

              {/* Break Minutes */}
              <div
                className="card-glow bg-card/50 border border-border rounded-xl p-6 text-center hover:scale-105 transition-transform duration-300 animate-slide-in-up"
                style={{ animationDelay: "200ms" }}
              >
                <div className="text-4xl font-bold text-pink-500 mb-2">{planData.breakMinutes}</div>
                <p className="text-muted-foreground font-medium">Break Minutes</p>
              </div>
            </div>

            {/* Schedule Description */}
            <div
              className="mb-8 p-6 bg-card/50 border border-primary/30 rounded-xl backdrop-blur-sm animate-slide-in-up"
              style={{ animationDelay: "250ms" }}
            >
              <p className="text-center text-lg text-foreground font-medium">{planData.schedule}</p>
            </div>

            {/* Details Section */}
            <div className="space-y-4 mb-8 animate-slide-in-up" style={{ animationDelay: "300ms" }}>
              <div className="p-4 bg-card/30 rounded-lg border border-border/50">
                <p className="text-sm">
                  <span className="font-semibold">Knowledge Level:</span>{" "}
                  <span className="capitalize text-primary">{brainDumpData.knowledge}</span>
                </p>
              </div>
              {brainDumpData.challenges.length > 0 && (
                <div className="p-4 bg-card/30 rounded-lg border border-border/50">
                  <p className="text-sm">
                    <span className="font-semibold">Challenges to Address:</span>
                  </p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {brainDumpData.challenges.map((challenge) => (
                      <span key={challenge} className="px-3 py-1 bg-primary/20 text-primary text-xs rounded-full">
                        {challenge}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 animate-slide-in-up" style={{ animationDelay: "350ms" }}>
              <button
                onClick={() => router.push("/dashboard")}
                className="flex-1 py-4 px-6 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-white rounded-lg font-semibold text-lg transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95"
              >
                View Dashboard
              </button>
              <button
                onClick={() => router.push("/brain-dump")}
                className="flex-1 py-4 px-6 bg-card hover:bg-card/80 border-2 border-primary/50 text-foreground rounded-lg font-semibold text-lg transition-all active:scale-95"
              >
                Adjust Plan
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
