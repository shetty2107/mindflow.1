"use client"
import { Navbar } from "@/components/navbar"
import { SignupForm } from "@/components/signup-form"

export default function SignupPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated background orbs */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-20 right-10 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl animate-float-delayed" />
      <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl animate-pulse" />

      <Navbar />

      <div className="min-h-screen flex items-center justify-center pt-20 pb-12 px-4 relative z-10">
        <div className="w-full max-w-md">
          {/* Glassmorphism Card */}
          <div className="backdrop-blur-2xl bg-white/5 border border-white/20 rounded-2xl p-8 shadow-2xl hover:border-white/40 transition-colors duration-300">
            <div className="text-center mb-8">
              <div className="text-5xl mb-4 inline-block">🚀</div>
              <h1 className="text-3xl font-bold text-white mb-2">Join MindFlow</h1>
              <p className="text-white/70">Start your personalized study journey</p>
            </div>

            <SignupForm />
          </div>

          {/* Social Proof */}
          <div className="mt-8 text-center text-white/60 text-sm">
            <p>Join 10,000+ students already learning with MindFlow</p>
          </div>
        </div>
      </div>
    </main>
  )
}
