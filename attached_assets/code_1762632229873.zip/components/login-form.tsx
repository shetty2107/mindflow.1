"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"

export function LoginForm() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    setTimeout(() => {
      if (email && password) {
        localStorage.setItem("userEmail", email)
        localStorage.setItem("isAuthenticated", "true")
        setIsLoading(false)
        router.push("/brain-dump")
      } else {
        setError("Please fill in all fields")
        setIsLoading(false)
      }
    }, 1000)
  }

  return (
    <div className="w-full space-y-6">
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Email Input */}
        <div className="relative group">
          <input
            type="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value)
              setError("")
            }}
            placeholder="Enter your email"
            className="w-full px-5 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 hover:border-white/30"
            required
          />
          <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl opacity-0 group-hover:opacity-20 blur transition-opacity duration-300 pointer-events-none" />
        </div>

        {/* Password Input */}
        <div className="relative group">
          <div className="flex items-center">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value)
                setError("")
              }}
              placeholder="Enter your password"
              className="w-full px-5 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 hover:border-white/30"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 text-white/50 hover:text-white/80 transition-colors"
            >
              {showPassword ? "👁️" : "👁️‍🗨️"}
            </button>
          </div>
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl opacity-0 group-hover:opacity-20 blur transition-opacity duration-300 pointer-events-none" />
        </div>

        {/* Error Message */}
        {error && (
          <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-200 text-sm animate-slide-in-down">
            {error}
          </div>
        )}

        {/* Remember Me & Forgot Password */}
        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2 cursor-pointer group">
            <input type="checkbox" className="w-4 h-4 rounded border-white/30 accent-purple-400" />
            <span className="text-white/70 group-hover:text-white transition-colors">Remember me</span>
          </label>
          <button type="button" className="text-white/70 hover:text-purple-300 transition-colors">
            Forgot password?
          </button>
        </div>

        {/* Login Button */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full py-3 px-6 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 disabled:opacity-50 text-white font-semibold rounded-xl transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/50 active:scale-95 transform relative overflow-hidden group"
        >
          <span className={`inline-flex items-center gap-2 ${isLoading ? "opacity-0" : ""}`}>
            Log In
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </span>
          {isLoading && (
            <span className="absolute inset-0 flex items-center justify-center">
              <span className="inline-block animate-spin">⚙️</span>
            </span>
          )}
        </button>
      </form>

      {/* Sign Up Link */}
      <div className="text-center text-white/70 text-sm">
        Don't have an account?{" "}
        <button
          onClick={() => router.push("/signup")}
          className="text-purple-300 hover:text-purple-200 font-semibold transition-colors underline"
        >
          Sign up for free
        </button>
      </div>
    </div>
  )
}
