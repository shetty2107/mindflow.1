"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"

export function SignupForm() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    studyGoal: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    setError("")
  }

  const handleNextStep = () => {
    if (step === 1) {
      if (!formData.firstName || !formData.lastName) {
        setError("Please fill in all fields")
        return
      }
      setStep(2)
    } else if (step === 2) {
      if (!formData.email) {
        setError("Please enter your email")
        return
      }
      setStep(3)
    } else if (step === 3) {
      if (!formData.password || formData.password.length < 6) {
        setError("Password must be at least 6 characters")
        return
      }
      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match")
        return
      }
      setStep(4)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.studyGoal) {
      setError("Please select a study goal")
      return
    }

    setIsLoading(true)
    setTimeout(() => {
      localStorage.setItem("userEmail", formData.email)
      localStorage.setItem("userName", `${formData.firstName} ${formData.lastName}`)
      localStorage.setItem("isAuthenticated", "true")
      setIsLoading(false)
      router.push("/brain-dump")
    }, 1000)
  }

  return (
    <div className="w-full">
      {/* Progress Indicator */}
      <div className="mb-8 flex gap-2">
        {[1, 2, 3, 4].map((s) => (
          <div
            key={s}
            className={`h-2 flex-1 rounded-full transition-all duration-300 ${
              s <= step ? "bg-gradient-to-r from-purple-500 to-blue-500" : "bg-white/20"
            }`}
          />
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Step 1: Name */}
        {step === 1 && (
          <div className="space-y-5 animate-slide-in-up">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">What's your name?</h2>
              <p className="text-white/70 text-sm">Let's start with the basics</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="relative group">
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  placeholder="First name"
                  className="w-full px-5 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 hover:border-white/30"
                />
                <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl opacity-0 group-hover:opacity-20 blur transition-opacity duration-300 pointer-events-none" />
              </div>
              <div className="relative group">
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  placeholder="Last name"
                  className="w-full px-5 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 hover:border-white/30"
                />
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl opacity-0 group-hover:opacity-20 blur transition-opacity duration-300 pointer-events-none" />
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Email */}
        {step === 2 && (
          <div className="space-y-5 animate-slide-in-up">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">Your email address</h2>
              <p className="text-white/70 text-sm">We'll use this to keep your account secure</p>
            </div>
            <div className="relative group">
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="you@example.com"
                className="w-full px-5 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 hover:border-white/30"
              />
              <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl opacity-0 group-hover:opacity-20 blur transition-opacity duration-300 pointer-events-none" />
            </div>
          </div>
        )}

        {/* Step 3: Password */}
        {step === 3 && (
          <div className="space-y-5 animate-slide-in-up">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">Create a password</h2>
              <p className="text-white/70 text-sm">Make it strong to keep your account safe</p>
            </div>
            <div className="relative group">
              <div className="flex items-center">
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="Enter password"
                  className="w-full px-5 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 hover:border-white/30"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 text-white/50 hover:text-white/80 transition-colors"
                >
                  {showPassword ? "👁️" : "👁️‍🗨️"}
                </button>
              </div>
              <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl opacity-0 group-hover:opacity-20 blur transition-opacity duration-300 pointer-events-none" />
            </div>
            <div className="relative group">
              <input
                type={showPassword ? "text" : "password"}
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                placeholder="Confirm password"
                className="w-full px-5 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300 hover:border-white/30"
              />
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl opacity-0 group-hover:opacity-20 blur transition-opacity duration-300 pointer-events-none" />
            </div>
          </div>
        )}

        {/* Step 4: Study Goal */}
        {step === 4 && (
          <div className="space-y-5 animate-slide-in-up">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">What's your main goal?</h2>
              <p className="text-white/70 text-sm">Help us personalize your experience</p>
            </div>
            <div className="space-y-3">
              {[
                { value: "exam", label: "📚 Pass an exam", description: "Get ready for a test or certification" },
                { value: "skill", label: "🎯 Learn a new skill", description: "Master a new subject or ability" },
                { value: "improve", label: "⬆️ Improve grades", description: "Boost your academic performance" },
                { value: "career", label: "💼 Career advancement", description: "Grow professionally" },
              ].map((goal) => (
                <label
                  key={goal.value}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-300 ${
                    formData.studyGoal === goal.value
                      ? "border-purple-500 bg-purple-500/20"
                      : "border-white/20 hover:border-white/40 bg-white/5"
                  }`}
                >
                  <input
                    type="radio"
                    name="studyGoal"
                    value={goal.value}
                    checked={formData.studyGoal === goal.value}
                    onChange={handleInputChange}
                    className="hidden"
                  />
                  <div className="font-semibold text-white">{goal.label}</div>
                  <div className="text-white/60 text-sm">{goal.description}</div>
                </label>
              ))}
            </div>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-200 text-sm animate-slide-in-down">
            {error}
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex gap-4 pt-6">
          {step > 1 && (
            <button
              type="button"
              onClick={() => setStep(step - 1)}
              className="flex-1 py-3 px-6 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl transition-all duration-300 border border-white/20"
            >
              Back
            </button>
          )}
          {step < 4 ? (
            <button
              type="button"
              onClick={handleNextStep}
              className="flex-1 py-3 px-6 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white font-semibold rounded-xl transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/50 active:scale-95 transform"
            >
              Next
            </button>
          ) : (
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 py-3 px-6 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 disabled:opacity-50 text-white font-semibold rounded-xl transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/50 active:scale-95 transform relative overflow-hidden group"
            >
              <span className={`inline-flex items-center gap-2 ${isLoading ? "opacity-0" : ""}`}>
                Create Account
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </span>
              {isLoading && (
                <span className="absolute inset-0 flex items-center justify-center">
                  <span className="inline-block animate-spin">⚙️</span>
                </span>
              )}
            </button>
          )}
        </div>
      </form>

      {/* Login Link */}
      <div className="text-center text-white/70 text-sm mt-6">
        Already have an account?{" "}
        <button
          onClick={() => router.push("/login")}
          className="text-purple-300 hover:text-purple-200 font-semibold transition-colors underline"
        >
          Log in
        </button>
      </div>
    </div>
  )
}
