"use client"

import { useEffect, useState } from "react"

export function FloatingObjects() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY })
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Floating background objects */}
      <div
        className="absolute w-96 h-96 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-3xl animate-float"
        style={{ top: "10%", left: "5%", animationDuration: "8s" }}
      />
      <div
        className="absolute w-72 h-72 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-full blur-3xl animate-float"
        style={{ top: "50%", right: "10%", animationDuration: "10s", animationDelay: "1s" }}
      />
      <div
        className="absolute w-80 h-80 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-float"
        style={{ bottom: "10%", left: "20%", animationDuration: "12s", animationDelay: "2s" }}
      />

      <div
        className="absolute w-40 h-40 bg-gradient-to-r from-orange-500/10 to-red-500/10 rounded-full blur-2xl transition-all duration-150"
        style={{
          left: `${mousePos.x}px`,
          top: `${mousePos.y}px`,
          transform: "translate(-50%, -50%)",
        }}
      />

      {/* Animated dots */}
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className="absolute w-2 h-2 bg-blue-400/40 rounded-full animate-pulse"
          style={{
            left: `${10 + i * 20}%`,
            top: `${20 + i * 15}%`,
            animationDelay: `${i * 0.2}s`,
          }}
        />
      ))}
    </div>
  )
}
