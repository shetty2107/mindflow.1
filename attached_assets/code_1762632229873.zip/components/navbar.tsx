"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState } from "react"

export function Navbar() {
  const router = useRouter()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const handleLogout = () => {
    localStorage.removeItem("mindflow_currentUser")
    router.push("/login")
  }

  return (
    <nav className="sticky top-0 z-40 bg-card border-b border-border backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-2 group">
            <span className="text-2xl group-hover:animate-float">🧠</span>
            <span className="font-bold text-xl bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              MindFlow
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link href="/" className="hover:text-primary transition-colors">
              Home
            </Link>
            <Link href="#features" className="hover:text-primary transition-colors">
              Features
            </Link>
            <Link href="#about" className="hover:text-primary transition-colors">
              About
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 hover:bg-accent rounded-lg transition-colors"
            >
              ☰
            </button>

            <div className="flex gap-2">
              <Link href="/signup" className="btn-primary hidden sm:inline-flex">
                Sign Up
              </Link>
              <Link href="/login" className="btn-outline">
                Login
              </Link>
            </div>

            <button onClick={handleLogout} className="btn-secondary hidden" id="logoutBtn">
              Logout
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden pb-4 space-y-2 animate-slide-in-down">
            <Link href="/" className="block px-4 py-2 hover:bg-accent rounded-lg transition-colors">
              Home
            </Link>
            <Link href="#features" className="block px-4 py-2 hover:bg-accent rounded-lg transition-colors">
              Features
            </Link>
            <Link href="#about" className="block px-4 py-2 hover:bg-accent rounded-lg transition-colors">
              About
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}
