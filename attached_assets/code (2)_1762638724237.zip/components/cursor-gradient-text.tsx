"use client"

import { useEffect, useRef, useState } from "react"

interface CursorGradientTextProps {
  children: string
  className?: string
}

export function CursorGradientText({ children, className = "" }: CursorGradientTextProps) {
  const textRef = useRef<HTMLHeadingElement>(null)
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY })
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  useEffect(() => {
    if (!textRef.current) return

    const rect = textRef.current.getBoundingClientRect()
    const textCenterX = rect.left + rect.width / 2
    const textCenterY = rect.top + rect.height / 2

    // Calculate distance from cursor to text center
    const distX = mousePos.x - textCenterX
    const distY = mousePos.y - textCenterY
    const distance = Math.sqrt(distX * distX + distY * distY)
    const angle = Math.atan2(distY, distX)

    // Create color based on angle and distance
    const hue = (angle * 180) / Math.PI + 180
    const saturation = Math.min(100, Math.max(70, 100 - distance / 10))
    const lightness = Math.min(60, Math.max(40, 50 - distance / 30))

    textRef.current.style.color = `hsl(${hue}, ${saturation}%, ${lightness}%)`
  }, [mousePos])

  return (
    <h1 ref={textRef} className={className}>
      {children}
    </h1>
  )
}
