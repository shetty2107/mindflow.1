"use client"

import type React from "react"

import { useState } from "react"

interface AuthFormProps {
  type: "login" | "signup"
}

export function AuthForm({ type }: AuthFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setSuccess("")

    const formData = new FormData(e.currentTarget)

    setTimeout(() => {
      if (type === "signup") {
        const email = formData.get("email")
        const password = formData.get("password")
        const name = formData.get("name")

        if (!email || !password || !name) {
          setError("Please fill all fields")
          setIsLoading(false)
          return
        }

        const users = JSON.parse(localStorage.getItem("mindflow_users") || "[]")
        if (users.find((u: any) => u.email === email)) {
          setError("Email already registered")
          setIsLoading(false)
          return
        }

        users.push({ id: Date.now(), email, password, name })
        localStorage.setItem("mindflow_users", JSON.stringify(users))
        localStorage.setItem("mindflow_currentUser", JSON.stringify({ email, name }))

        setSuccess("Account created! Redirecting...")
        setTimeout(() => (window.location.href = "/dashboard"), 1500)
      } else {
        const email = formData.get("email")
        const password = formData.get("password")

        if (!email || !password) {
          setError("Please fill all fields")
          setIsLoading(false)
          return
        }

        const users = JSON.parse(localStorage.getItem("mindflow_users") || "[]")
        const user = users.find((u: any) => u.email === email && u.password === password)

        if (!user) {
          setError("Invalid email or password")
          setIsLoading(false)
          return
        }

        localStorage.setItem("mindflow_currentUser", JSON.stringify({ email: user.email, name: user.name }))
        setSuccess("Login successful! Redirecting...")
        setTimeout(() => (window.location.href = "/dashboard"), 1500)
      }

      setIsLoading(false)
    }, 600)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 animate-slide-in-up">
      {type === "signup" && (
        <div>
          <label className="block text-sm font-medium mb-2">Full Name</label>
          <input
            type="text"
            name="name"
            placeholder="John Doe"
            className="w-full px-4 py-2 rounded-lg border border-border bg-card hover:border-primary/50 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
            required
          />
        </div>
      )}

      <div>
        <label className="block text-sm font-medium mb-2">Email</label>
        <input
          type="email"
          name="email"
          placeholder="you@example.com"
          className="w-full px-4 py-2 rounded-lg border border-border bg-card hover:border-primary/50 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Password</label>
        <input
          type="password"
          name="password"
          placeholder="••••••••"
          minLength={8}
          className="w-full px-4 py-2 rounded-lg border border-border bg-card hover:border-primary/50 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
          required
        />
      </div>

      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 rounded-lg text-sm animate-slide-in-down">
          {error}
        </div>
      )}

      {success && (
        <div className="p-3 bg-green-500/10 border border-green-500/30 text-green-600 dark:text-green-400 rounded-lg text-sm animate-slide-in-down">
          {success}
        </div>
      )}

      <button
        type="submit"
        disabled={isLoading}
        className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? "Processing..." : type === "login" ? "Sign In" : "Create Account"}
      </button>
    </form>
  )
}
