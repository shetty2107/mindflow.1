"use client"

import { useEffect, useState } from "react"

export function FloatingObjects() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY })
    }

    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Primary gradient orbs */}
      <div
        className="absolute w-96 h-96 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-3xl animate-float"
        style={{ top: "10%", left: "5%", animationDuration: "8s" }}
      />
      <div
        className="absolute w-72 h-72 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-full blur-3xl animate-float"
        style={{ top: "50%", right: "10%", animationDuration: "10s", animationDelay: "1s" }}
      />
      <div
        className="absolute w-80 h-80 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-float"
        style={{ bottom: "10%", left: "20%", animationDuration: "12s", animationDelay: "2s" }}
      />

      {/* Additional creative orbs */}
      <div
        className="absolute w-64 h-64 bg-gradient-to-r from-orange-500/15 to-red-500/15 rounded-full blur-3xl animate-float"
        style={{
          top: "30%",
          left: "60%",
          animationDuration: "15s",
          animationDelay: "3s",
        }}
      />
      <div
        className="absolute w-56 h-56 bg-gradient-to-r from-green-500/10 to-teal-500/10 rounded-full blur-2xl animate-float"
        style={{
          bottom: "20%",
          right: "15%",
          animationDuration: "18s",
          animationDelay: "1.5s",
        }}
      />

      {/* Mouse-tracking glow */}
      <div
        className="absolute w-40 h-40 bg-gradient-to-r from-orange-500/10 to-red-500/10 rounded-full blur-2xl transition-all duration-150"
        style={{
          left: `${mousePos.x}px`,
          top: `${mousePos.y}px`,
          transform: "translate(-50%, -50%)",
        }}
      />

      {/* Parallax scroll effect orb */}
      <div
        className="absolute w-52 h-52 bg-gradient-to-r from-indigo-500/15 to-purple-500/15 rounded-full blur-3xl"
        style={{
          bottom: `${scrollY * 0.5}px`,
          left: "40%",
          opacity: 0.6,
        }}
      />

      {/* Animated floating dots */}
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="absolute w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-pulse"
          style={{
            left: `${10 + i * 12}%`,
            top: `${20 + (i % 3) * 25}%`,
            animationDelay: `${i * 0.2}s`,
            opacity: 0.6,
          }}
        />
      ))}

      {/* Connecting lines effect (subtle) */}
      <svg className="absolute inset-0 w-full h-full opacity-10">
        <defs>
          <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#a855f7" />
          </linearGradient>
        </defs>
        <line x1="10%" y1="20%" x2="80%" y2="80%" stroke="url(#lineGradient)" strokeWidth="0.5" />
        <line x1="85%" y1="30%" x2="15%" y2="70%" stroke="url(#lineGradient)" strokeWidth="0.5" />
        <line x1="50%" y1="10%" x2="50%" y2="90%" stroke="url(#lineGradient)" strokeWidth="0.5" />
      </svg>
    </div>
  )
}
