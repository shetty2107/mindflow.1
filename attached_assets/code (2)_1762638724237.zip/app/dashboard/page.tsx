"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { FloatingObjects } from "@/components/floating-objects"

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [selectedEmotion, setSelectedEmotion] = useState("")
  const [brainDumpData, setBrainDumpData] = useState<any>(null)
  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: "jhgfds - Part 1/4",
      duration: "25 min",
      difficulty: "EASY",
      subject: "MATH",
      focus: "Understanding core concepts",
      tip: "Use the Pomodoro technique (25 min focus, 5 min break)",
      done: false,
    },
    {
      id: 2,
      title: "Review Key Formulas",
      duration: "15 min",
      difficulty: "EASY",
      subject: "MATH",
      focus: "Quick revision",
      tip: "Quick review for retention",
      done: false,
    },
    {
      id: 3,
      title: "Practice Problem Set",
      duration: "45 min",
      difficulty: "MEDIUM",
      subject: "MATH",
      focus: "Application practice",
      tip: "Start with easier problems",
      done: false,
    },
    {
      id: 4,
      title: "Take Practice Test",
      duration: "1h",
      difficulty: "HARD",
      subject: "MATH",
      focus: "Full assessment",
      tip: "Complete without breaks",
      done: false,
    },
  ])

  useEffect(() => {
    const currentUser = localStorage.getItem("mindflow_currentUser")
    if (!currentUser) {
      const defaultUser = { name: "Student" }
      setUser(defaultUser)
      localStorage.setItem("mindflow_currentUser", JSON.stringify(defaultUser))
    } else {
      setUser(JSON.parse(currentUser))
    }

    const brainDumpData = localStorage.getItem("brainDumpData")
    if (brainDumpData) {
      setBrainDumpData(JSON.parse(brainDumpData))
    }
  }, [])

  const handleTaskToggle = (id: number) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)))
  }

  const emotions = [
    { emoji: "😊", label: "Happy & Focused" },
    { emoji: "😐", label: "Normal" },
    { emoji: "😰", label: "Anxious" },
    { emoji: "😟", label: "Tired" },
    { emoji: "😤", label: "Frustrated" },
  ]

  const completedTasks = tasks.filter((t) => t.done).length
  const progressPercent = Math.round((completedTasks / tasks.length) * 100)

  const emotionMessages: Record<string, string> = {
    "Happy & Focused": "🎯 Great! Let's tackle those challenging tasks first.",
    Normal: "✅ Perfect for steady, consistent progress.",
    Anxious: "🧘 Take it slow - break tasks into smaller steps.",
    Tired: "⚡ Let's do lighter tasks and take more breaks.",
    Frustrated: "🎵 Step back and do something enjoyable first.",
  }

  return (
    <main>
      <FloatingObjects />
      <Navbar />

      <div className="min-h-screen bg-background pt-20 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Welcome Section */}
          <section className="animate-slide-in-up">
            <div className="text-center mb-8">
              <h1 className="text-4xl md:text-5xl font-bold mb-2">Hi, {user?.name || "Student"}! 👋</h1>
              <p className="text-lg text-muted-foreground">Let's crush your study goals today</p>
            </div>

            {/* Emotion Section */}
            <div>
              <h2 className="text-2xl font-bold mb-4 ml-1">How are you feeling right now?</h2>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-4">
                {emotions.map((emotion) => (
                  <button
                    key={emotion.label}
                    onClick={() => setSelectedEmotion(emotion.label)}
                    className={`p-4 rounded-lg border-2 transition-all duration-300 backdrop-blur-sm ${
                      selectedEmotion === emotion.label
                        ? "border-primary bg-primary/20 scale-105 shadow-lg shadow-primary/30"
                        : "border-border/50 bg-card/30 hover:border-primary/50 hover:bg-card/50"
                    }`}
                  >
                    <div className="text-3xl mb-2">{emotion.emoji}</div>
                    <div className="text-xs font-medium text-center text-foreground">{emotion.label}</div>
                  </button>
                ))}
              </div>

              {/* Emotion Message */}
              {selectedEmotion && (
                <div className="p-4 bg-gradient-to-r from-primary/10 to-purple-500/10 border border-primary/30 rounded-lg animate-slide-in-up">
                  <p className="text-sm font-medium text-foreground">
                    {emotionMessages[selectedEmotion] || "Keep going!"}
                  </p>
                </div>
              )}
            </div>
          </section>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content - Today's Study Plan */}
            <div className="lg:col-span-2 space-y-8">
              <section className="animate-slide-in-up" style={{ animationDelay: "100ms" }}>
                <h2 className="text-2xl font-bold mb-4">Today's Study Plan</h2>
                <p className="text-sm text-muted-foreground mb-4">
                  {brainDumpData?.energyTime && `Optimized for your ${brainDumpData.energyTime} energy`}
                </p>

                <div className="space-y-4">
                  {tasks.map((task, i) => (
                    <div
                      key={task.id}
                      onClick={() => handleTaskToggle(task.id)}
                      className={`card-glow cursor-pointer transition-all duration-300 overflow-hidden ${
                        task.done ? "opacity-60" : "hover:shadow-lg hover:shadow-primary/20"
                      }`}
                      style={{ animationDelay: `${i * 50}ms` }}
                    >
                      <div className="p-6 space-y-3">
                        {/* Task Header */}
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-4 flex-1">
                            <input
                              type="checkbox"
                              checked={task.done}
                              onChange={() => {}}
                              className="w-6 h-6 rounded mt-1 cursor-pointer accent-primary"
                            />
                            <div className="flex-1">
                              <h3
                                className={`font-bold text-lg transition-all ${
                                  task.done ? "line-through text-muted-foreground" : "text-foreground"
                                }`}
                              >
                                {task.title}
                              </h3>
                              <div className="flex flex-wrap gap-2 mt-2">
                                <span className="px-2 py-1 bg-green-500/20 text-green-600 dark:text-green-400 text-xs font-semibold rounded">
                                  {task.difficulty}
                                </span>
                                <span className="px-2 py-1 bg-blue-500/20 text-blue-600 dark:text-blue-400 text-xs font-semibold rounded">
                                  {task.subject}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-sm font-semibold text-muted-foreground">{task.duration}</span>
                          </div>
                        </div>

                        {/* Task Details */}
                        <div className="pl-10 border-l-2 border-primary/30 space-y-2">
                          <p className="text-sm text-foreground">
                            <span className="font-semibold">Focus:</span> {task.focus}
                          </p>
                          <p className="text-sm text-muted-foreground italic flex items-center gap-2">
                            <span>💡</span> {task.tip}
                          </p>
                        </div>
                      </div>

                      {/* Task Footer - Start Button */}
                      {!task.done && (
                        <div className="px-6 py-3 border-t border-border/50 bg-gradient-to-r from-primary/5 to-purple-500/5">
                          <button className="w-full py-2 px-4 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-white rounded-lg font-semibold text-sm transition-all">
                            Start
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            </div>

            {/* Sidebar */}
            <aside className="space-y-6">
              {/* Today's Progress */}
              <div className="card-glow animate-slide-in-up" style={{ animationDelay: "200ms" }}>
                <h3 className="font-bold text-lg mb-6">Today's Progress</h3>
                <div className="flex flex-col items-center justify-center">
                  {/* Circular Progress */}
                  <div className="relative w-40 h-40 mb-6">
                    <svg className="transform -rotate-90 w-40 h-40">
                      <circle
                        cx="80"
                        cy="80"
                        r="70"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="6"
                        className="text-muted opacity-20"
                      />
                      <circle
                        cx="80"
                        cy="80"
                        r="70"
                        fill="none"
                        stroke="url(#grad1)"
                        strokeWidth="6"
                        strokeDasharray={`${(2 * Math.PI * 70 * progressPercent) / 100} ${2 * Math.PI * 70}`}
                        strokeLinecap="round"
                        className="transition-all duration-500"
                      />
                      <defs>
                        <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="var(--color-primary)" />
                          <stop offset="100%" stopColor="rgb(168, 85, 247)" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <p className="text-4xl font-bold text-primary">{progressPercent}%</p>
                      <p className="text-xs text-muted-foreground">Complete</p>
                    </div>
                  </div>

                  <p className="text-center text-sm text-muted-foreground font-medium">
                    {completedTasks} of {tasks.length} tasks done
                  </p>
                </div>
              </div>

              {/* Study Streak */}
              <div className="card-glow animate-slide-in-up" style={{ animationDelay: "300ms" }}>
                <h3 className="font-bold text-lg mb-3">Study Streak</h3>
                <div className="text-5xl font-bold text-transparent bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text mb-2">
                  7
                </div>
                <p className="text-sm text-muted-foreground">
                  Day Streak! <span className="text-lg">🔥</span> Keep it up! 💪
                </p>
              </div>

              {/* Daily Tip */}
              <div
                className="card-glow bg-gradient-to-br from-primary/20 to-purple-500/20 animate-slide-in-up"
                style={{ animationDelay: "400ms" }}
              >
                <h3 className="font-bold text-lg mb-3">Daily Tip</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  <span className="text-lg">💡</span> Use the Pomodoro Technique: Study 25 min, break 5 min for maximum
                  focus and retention!
                </p>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </main>
  )
}
