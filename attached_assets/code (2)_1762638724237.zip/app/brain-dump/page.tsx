"use client"

import type React from "react"

import { Navbar } from "@/components/navbar"
import { FloatingObjects } from "@/components/floating-objects"
import { useState } from "react"

export default function BrainDumpPage() {
  const [formData, setFormData] = useState({
    tasks: "",
    deadline: "",
    knowledge: "beginner",
    hours: "4",
    challenges: [] as string[],
    subject: "",
    customSubject: "",
    energyTime: "morning",
  })

  const [expandedSections, setExpandedSections] = useState({
    tasks: true,
    challenges: false,
    preferences: false,
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      challenges: prev.challenges.includes(value)
        ? prev.challenges.filter((c) => c !== value)
        : [...prev.challenges, value],
    }))
  }

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    localStorage.setItem("brainDumpData", JSON.stringify(formData))
    window.location.href = "/results"
  }

  return (
    <main>
      <FloatingObjects />
      <Navbar />

      <div className="min-h-screen pt-20 pb-12 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="card-glow backdrop-blur-sm bg-background/95 border border-border rounded-2xl p-8 md:p-12 animate-slide-in-up">
            <div className="text-center mb-8">
              <div className="text-6xl mb-4 inline-block animate-float">🧠</div>
              <h1 className="text-4xl md:text-5xl font-bold mb-3">Brain Dump</h1>
              <p className="text-lg text-muted-foreground">
                Tell us everything you need to study. AI will organize it for you.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Tasks Section - Add toggle animation */}
              <div className="border border-border rounded-xl overflow-hidden hover:border-primary/50 transition-colors">
                <button
                  type="button"
                  onClick={() => toggleSection("tasks")}
                  className="w-full px-6 py-4 bg-card hover:bg-card/80 transition-colors flex items-center justify-between group"
                >
                  <span className="text-lg font-semibold">📝 What do you need to study?</span>
                  <span
                    className={`transform transition-transform duration-300 ${
                      expandedSections.tasks ? "rotate-180" : ""
                    }`}
                  >
                    ▼
                  </span>
                </button>

                {expandedSections.tasks && (
                  <div className="px-6 py-4 border-t border-border/50 bg-background/50 animate-slide-in-down">
                    <textarea
                      name="tasks"
                      value={formData.tasks}
                      onChange={handleInputChange}
                      placeholder="Example: Math exam Nov 20, Physics homework chapter 5, Chemistry lab report..."
                      className="w-full h-32 p-4 bg-card border border-border rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all resize-none"
                      required
                    />
                  </div>
                )}
              </div>

              {/* Deadline and Knowledge */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-3">📅 Main Deadline</label>
                  <input
                    type="date"
                    name="deadline"
                    value={formData.deadline}
                    onChange={handleInputChange}
                    className="w-full p-3 bg-card border border-border rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-3">📊 Knowledge Level</label>
                  <select
                    name="knowledge"
                    value={formData.knowledge}
                    onChange={handleInputChange}
                    className="w-full p-3 bg-card border border-border rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all cursor-pointer"
                  >
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>
              </div>

              {/* Hours and Energy Time */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-3">⏰ Study Hours Today</label>
                  <select
                    name="hours"
                    value={formData.hours}
                    onChange={handleInputChange}
                    className="w-full p-3 bg-card border border-border rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all cursor-pointer"
                  >
                    <option value="2">2 hours</option>
                    <option value="4">4 hours</option>
                    <option value="6">6 hours</option>
                    <option value="8">8+ hours</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-3">🌙 When Do You Focus Best?</label>
                  <select
                    name="energyTime"
                    value={formData.energyTime}
                    onChange={handleInputChange}
                    className="w-full p-3 bg-card border border-border rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all cursor-pointer"
                  >
                    <option value="morning">Morning Person</option>
                    <option value="afternoon">Afternoon Person</option>
                    <option value="night">Night Owl</option>
                    <option value="unsure">Not Sure</option>
                  </select>
                </div>
              </div>

              {/* Challenges Section - Add collapsible toggle */}
              <div className="border border-border rounded-xl overflow-hidden hover:border-primary/50 transition-colors">
                <button
                  type="button"
                  onClick={() => toggleSection("challenges")}
                  className="w-full px-6 py-4 bg-card hover:bg-card/80 transition-colors flex items-center justify-between"
                >
                  <span className="text-lg font-semibold">😰 Your Challenges</span>
                  <span
                    className={`transform transition-transform duration-300 ${
                      expandedSections.challenges ? "rotate-180" : ""
                    }`}
                  >
                    ▼
                  </span>
                </button>

                {expandedSections.challenges && (
                  <div className="px-6 py-4 border-t border-border/50 bg-background/50 animate-slide-in-down">
                    <div className="space-y-3">
                      {[
                        { value: "concentration", label: "Difficulty concentrating" },
                        { value: "procrastination", label: "Procrastination" },
                        { value: "anxiety", label: "Anxiety while studying" },
                        { value: "memory", label: "Poor memory/retention" },
                        { value: "time", label: "Time management issues" },
                      ].map((challenge) => (
                        <label
                          key={challenge.value}
                          className="flex items-center gap-3 p-3 rounded-lg hover:bg-card/50 transition-colors cursor-pointer group"
                        >
                          <input
                            type="checkbox"
                            checked={formData.challenges.includes(challenge.value)}
                            onChange={() => handleCheckboxChange(challenge.value)}
                            className="w-5 h-5 rounded border-2 border-border cursor-pointer accent-primary"
                          />
                          <span className="group-hover:text-primary transition-colors">{challenge.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Subject Section - Add collapsible preferences */}
              <div className="border border-border rounded-xl overflow-hidden hover:border-primary/50 transition-colors">
                <button
                  type="button"
                  onClick={() => toggleSection("preferences")}
                  className="w-full px-6 py-4 bg-card hover:bg-card/80 transition-colors flex items-center justify-between"
                >
                  <span className="text-lg font-semibold">📚 Subject & Preferences</span>
                  <span
                    className={`transform transition-transform duration-300 ${
                      expandedSections.preferences ? "rotate-180" : ""
                    }`}
                  >
                    ▼
                  </span>
                </button>

                {expandedSections.preferences && (
                  <div className="px-6 py-4 border-t border-border/50 bg-background/50 animate-slide-in-down space-y-4">
                    <div>
                      <label className="block text-sm font-semibold mb-3">What subject are you studying?</label>
                      <select
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        className="w-full p-3 bg-card border border-border rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all cursor-pointer"
                        required
                      >
                        <option value="">Select subject...</option>
                        <option value="math">Mathematics</option>
                        <option value="science">Science</option>
                        <option value="history">History</option>
                        <option value="language">Language</option>
                        <option value="literature">Literature</option>
                        <option value="economics">Economics</option>
                        <option value="programming">Programming</option>
                        <option value="art">Art</option>
                        <option value="music">Music</option>
                        <option value="psychology">Psychology</option>
                        <option value="other">Other Subject</option>
                      </select>
                    </div>

                    {formData.subject === "other" && (
                      <div className="animate-slide-in-down">
                        <label className="block text-sm font-semibold mb-3">Enter your subject name</label>
                        <input
                          type="text"
                          name="customSubject"
                          value={formData.customSubject}
                          onChange={handleInputChange}
                          placeholder="e.g., Philosophy, Nursing, Engineering"
                          className="w-full p-3 bg-card border border-border rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-4 px-6 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-white rounded-lg font-semibold text-lg transition-all hover:shadow-lg hover:shadow-primary/30 active:scale-95 transform duration-200"
              >
                Generate My Personalized Plan ✨
              </button>
            </form>
          </div>
        </div>
      </div>
    </main>
  )
}
