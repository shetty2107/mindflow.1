"use client"
import { Navbar } from "@/components/navbar"
import { FloatingObjects } from "@/components/floating-objects"
import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden relative">
      <FloatingObjects />
      <Navbar />

      <div className="relative z-10 min-h-screen flex items-center justify-center px-4 pt-20 pb-12">
        <div className="max-w-6xl w-full grid md:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Left Side - Branding */}
          <div
            className="hidden md:flex flex-col justify-center space-y-8 animate-slide-in-up"
            style={{ animationDelay: "0.1s" }}
          >
            <div className="space-y-6">
              <h1 className="text-6xl lg:text-7xl font-black text-white leading-tight">Welcome Back</h1>
              <p className="text-xl text-white/70 font-light leading-relaxed max-w-md">
                Continue your learning journey with MindFlow. Your personalized study plans are waiting for you.
              </p>
            </div>

            {/* Feature Highlights */}
            <div className="space-y-4 pt-8 border-t border-white/10">
              {[
                { emoji: "🧠", title: "AI-Powered Planning", desc: "Smart study schedules" },
                { emoji: "📊", title: "Progress Tracking", desc: "Visualize your growth" },
                { emoji: "⚡", title: "Personalized Plans", desc: "Tailored to your needs" },
              ].map((feature, i) => (
                <div key={i} className="flex gap-4 group cursor-pointer">
                  <span className="text-3xl group-hover:scale-110 transition-transform">{feature.emoji}</span>
                  <div>
                    <h3 className="font-semibold text-white group-hover:text-purple-300 transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-white/50">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Side - Login Form */}
          <div className="flex justify-center animate-slide-in-up" style={{ animationDelay: "0.2s" }}>
            <div className="w-full max-w-md">
              {/* Form Card */}
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 rounded-2xl blur-xl opacity-40 group-hover:opacity-60 transition-opacity duration-500" />
                <div className="relative bg-white/5 backdrop-blur-2xl border border-white/20 rounded-2xl p-8 space-y-8">
                  <div className="text-center space-y-2">
                    <div className="text-5xl mb-4 animate-float">🚀</div>
                    <h2 className="text-3xl font-bold text-white">Sign in</h2>
                    <p className="text-white/60 text-sm">Continue your learning adventure</p>
                  </div>

                  <LoginForm />

                  {/* Divider */}
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-white/10" />
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-3 bg-slate-900/50 text-white/50">or continue with</span>
                    </div>
                  </div>

                  {/* Social Login */}
                  <div className="grid grid-cols-3 gap-3">
                    {["Google", "GitHub", "Apple"].map((provider) => (
                      <button
                        key={provider}
                        type="button"
                        className="py-2 px-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-white/60 hover:text-white text-sm font-medium transition-all duration-300 hover:border-white/30"
                      >
                        {provider === "Google" && "🔍"}
                        {provider === "GitHub" && "🐙"}
                        {provider === "Apple" && "🍎"}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="mt-8 text-center text-xs text-white/50 space-y-2">
                <p>🔒 Your data is secure and encrypted</p>
                <p>✅ Trusted by 10,000+ students</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Animated gradient orbs */}
      <div
        className="absolute top-20 right-10 w-96 h-96 bg-purple-600/20 rounded-full filter blur-3xl animate-float"
        style={{ animationDuration: "8s" }}
      />
      <div
        className="absolute bottom-0 left-10 w-96 h-96 bg-blue-600/20 rounded-full filter blur-3xl animate-float"
        style={{ animationDuration: "10s", animationDelay: "2s" }}
      />
    </main>
  )
}
