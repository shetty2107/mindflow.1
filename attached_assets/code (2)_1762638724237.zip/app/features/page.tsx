"use client"

import { Navbar } from "@/components/navbar"

export default function FeaturesPage() {
  const features = [
    {
      title: "Lightning Fast",
      description: "Optimized performance with 99.99% uptime guarantee",
      icon: "⚡",
    },
    {
      title: "Secure & Reliable",
      description: "Enterprise-grade security with SSL encryption",
      icon: "🔒",
    },
    {
      title: "Real-Time Analytics",
      description: "Live insights and comprehensive reporting",
      icon: "📊",
    },
    {
      title: "Team Collaboration",
      description: "Seamless teamwork with advanced permissions",
      icon: "👥",
    },
    {
      title: "24/7 Support",
      description: "Expert support team always ready to help",
      icon: "🎧",
    },
    {
      title: "Easy Integration",
      description: "Connect with 500+ apps and services",
      icon: "🔗",
    },
  ]

  return (
    <main>
      <Navbar />

      <section className="min-h-screen bg-gradient-to-b from-background via-slate-50 dark:via-slate-900 to-background px-4 py-20">
        <div className="max-w-6xl mx-auto space-y-16">
          <div className="text-center space-y-6 animate-slide-in-up">
            <h1 className="text-5xl md:text-6xl font-bold text-slate-950 dark:text-slate-50">Powerful Features</h1>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Everything you need to succeed, all in one platform
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, i) => (
              <div
                key={i}
                className="bg-white dark:bg-slate-800/50 backdrop-blur border border-slate-200 dark:border-slate-700 rounded-xl p-8 hover:shadow-xl transition-all duration-300 hover:border-blue-400 dark:hover:border-blue-500 animate-slide-in-up"
                style={{ animationDelay: `${i * 50}ms` }}
              >
                <div className="text-5xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-slate-50 mb-2">{feature.title}</h3>
                <p className="text-slate-600 dark:text-slate-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}
