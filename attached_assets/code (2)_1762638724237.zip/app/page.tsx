"use client"

import { Navbar } from "@/components/navbar"
import { CursorGradientText } from "@/components/cursor-gradient-text"
import { FloatingObjects } from "@/components/floating-objects"
import { useEffect, useState } from "react"

export default function HomePage() {
  const [activeFeature, setActiveFeature] = useState(0)
  const [showBenefits, setShowBenefits] = useState(true)
  const [studyMode, setStudyMode] = useState("focus")

  useEffect(() => {
    const user = localStorage.getItem("mindflow_currentUser")
    if (user) {
      const logoutBtn = document.getElementById("logoutBtn")
      if (logoutBtn) logoutBtn.classList.remove("hidden")
    }
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % 4)
    }, 4000)
    return () => clearInterval(timer)
  }, [])

  return (
    <main>
      <Navbar />
      <FloatingObjects />

      {/* Hero Section */}
      <section className="relative min-h-screen bg-gradient-to-b from-background via-card/50 to-background flex items-center justify-center px-4 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-grid-pattern opacity-5" />
        </div>

        <div className="max-w-4xl mx-auto text-center space-y-8 animate-slide-in-up">
          <div className="text-7xl md:text-8xl font-bold animate-float hover:scale-110 transition-transform cursor-pointer">
            🧠
          </div>

          <CursorGradientText className="text-4xl md:text-6xl font-bold leading-tight transition-colors duration-100">
            Your Brain. Your Way. Your Study.
          </CursorGradientText>

          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Personalized study plans that adapt to your mental health and energy levels using AI
          </p>

          <div className="flex flex-wrap justify-center gap-2 pt-4">
            {["focus", "relax", "power"].map((mode) => (
              <button
                key={mode}
                onClick={() => setStudyMode(mode)}
                className={`px-4 py-2 rounded-full font-medium transition-all duration-300 capitalize ${
                  studyMode === mode
                    ? "bg-primary text-primary-foreground scale-105 shadow-lg"
                    : "bg-secondary/50 text-secondary-foreground hover:bg-secondary/70"
                }`}
              >
                {mode === "focus" && "🎯"}
                {mode === "relax" && "🧘"}
                {mode === "power" && "⚡"}
                {mode}
              </button>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <a href="/login" className="btn-primary text-lg group relative overflow-hidden">
              <span className="relative z-10">Start Your Journey</span>
              <span className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 group-hover:opacity-20 transition-opacity" />
            </a>
            <a href="#features" className="btn-outline text-lg hover:gap-2 transition-all">
              Learn More ↓
            </a>
          </div>
        </div>
      </section>

      {/* Features Section with Toggle */}
      <section id="features" className="relative py-20 px-4 bg-gradient-to-b from-background to-card/30">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between mb-16 gap-4">
            <h2 className="text-4xl md:text-5xl font-bold animate-slide-in-up">How MindFlow Helps You</h2>

            <button
              onClick={() => setShowBenefits(!showBenefits)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                showBenefits
                  ? "bg-primary text-primary-foreground shadow-lg scale-105"
                  : "bg-secondary/50 text-secondary-foreground hover:bg-secondary"
              }`}
            >
              {showBenefits ? "✨ Show Benefits" : "Hide Benefits"}
            </button>
          </div>

          {showBenefits && (
            <div className="grid md:grid-cols-2 gap-8 animate-fade-in">
              {[
                {
                  icon: "📝",
                  title: "Brain Dump",
                  desc: "Overwhelmed? Type everything. AI breaks it into manageable steps.",
                },
                {
                  icon: "⚡",
                  title: "Energy Mapper",
                  desc: "Schedule tasks during YOUR peak hours - morning or night.",
                },
                {
                  icon: "😊",
                  title: "Emotion Tracker",
                  desc: "Feeling anxious? We adapt your plan in real-time.",
                },
                {
                  icon: "🎉",
                  title: "Progress Celebration",
                  desc: "Complete tasks, earn streaks, see your growth.",
                },
              ].map((feature, i) => (
                <div
                  key={i}
                  onClick={() => setActiveFeature(i)}
                  className={`card-glow hover:translate-y-[-8px] cursor-pointer transition-all duration-300 animate-slide-in-up relative overflow-hidden group ${
                    activeFeature === i ? "ring-2 ring-primary scale-105" : ""
                  }`}
                  style={{ animationDelay: `${i * 100}ms` }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative z-10">
                    <div className="text-5xl mb-4 group-hover:scale-125 transition-transform duration-300">
                      {feature.icon}
                    </div>
                    <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* About Section with Interactive Toggle */}
      <section id="about" className="relative py-20 px-4 bg-background">
        <div className="max-w-3xl mx-auto text-center space-y-6 animate-slide-in-up">
          <h2 className="text-4xl md:text-5xl font-bold">Built with Care</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            We built MindFlow because we know what it's like to study with anxiety, procrastination, and overwhelm.
            While other apps force one-size-fits-all schedules, MindFlow uses AI to create plans that adapt to YOUR
            mental health, energy levels, and unique challenges. Every task is broken into dopamine-friendly steps.
            Every emotion gets a personalized response. Every completed task is celebrated.
          </p>

          <div className="grid grid-cols-3 gap-4 mt-12 pt-8 border-t border-border">
            {[
              { label: "Happy Users", value: "10K+" },
              { label: "Tasks Completed", value: "1M+" },
              { label: "Hours Optimized", value: "5M+" },
            ].map((stat, i) => (
              <div
                key={i}
                className="card-glow hover:scale-110 transition-transform animate-slide-in-up"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className="text-3xl font-bold text-primary">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-8 px-4 text-center text-muted-foreground relative">
        <div className="max-w-6xl mx-auto">
          <p>&copy; 2025 MindFlow Team | Built for Students Who Deserve Better</p>
          <div className="flex justify-center gap-6 mt-4 text-sm">
            <a href="#" className="hover:text-foreground transition-colors">
              Privacy
            </a>
            <a href="#" className="hover:text-foreground transition-colors">
              Terms
            </a>
            <a href="#" className="hover:text-foreground transition-colors">
              Contact
            </a>
          </div>
        </div>
      </footer>
    </main>
  )
}
