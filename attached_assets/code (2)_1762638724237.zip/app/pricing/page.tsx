"use client"

import { Navbar } from "@/components/navbar"
import { Check } from "lucide-react"

export default function PricingPage() {
  const plans = [
    {
      name: "Starter",
      price: "$29",
      description: "Perfect for individuals",
      features: ["Up to 5 projects", "Basic analytics", "Email support", "1GB storage"],
      popular: false,
    },
    {
      name: "Professional",
      price: "$79",
      description: "For growing teams",
      features: [
        "Unlimited projects",
        "Advanced analytics",
        "Priority support",
        "100GB storage",
        "Team collaboration",
        "API access",
      ],
      popular: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For large organizations",
      features: [
        "Everything in Pro",
        "Dedicated support",
        "Custom integrations",
        "Unlimited storage",
        "Advanced security",
        "SLA guarantee",
      ],
      popular: false,
    },
  ]

  return (
    <main>
      <Navbar />

      <section className="min-h-screen bg-gradient-to-b from-background to-slate-50 dark:to-slate-900 px-4 py-20">
        <div className="max-w-6xl mx-auto space-y-16">
          <div className="text-center space-y-6 animate-slide-in-up">
            <h1 className="text-5xl md:text-6xl font-bold text-slate-950 dark:text-slate-50">
              Simple, Transparent Pricing
            </h1>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Choose the perfect plan for your needs. Always flexible to scale.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, i) => (
              <div
                key={i}
                className={`rounded-2xl p-8 transition-all duration-300 animate-slide-in-up ${
                  plan.popular
                    ? "bg-gradient-to-br from-blue-600 to-indigo-600 text-white shadow-2xl scale-105"
                    : "bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-950 dark:text-slate-50 hover:shadow-xl hover:border-blue-400"
                }`}
                style={{ animationDelay: `${i * 50}ms` }}
              >
                {plan.popular && (
                  <div className="bg-white/20 text-white px-4 py-1 rounded-full text-sm font-semibold inline-block mb-4">
                    Most Popular
                  </div>
                )}
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <p className={plan.popular ? "text-blue-100" : "text-slate-600 dark:text-slate-400"}>
                  {plan.description}
                </p>
                <div className="my-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  {plan.price !== "Custom" && (
                    <span className={plan.popular ? "text-blue-100" : "text-slate-600"}>/month</span>
                  )}
                </div>
                <button
                  className={`w-full py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 active:scale-95 ${
                    plan.popular
                      ? "bg-white text-blue-600 hover:bg-slate-100"
                      : "bg-blue-600 text-white hover:bg-blue-700"
                  }`}
                >
                  Get Started
                </button>
                <div className="mt-8 space-y-4">
                  {plan.features.map((feature, j) => (
                    <div key={j} className="flex items-start gap-3">
                      <Check className="w-5 h-5 flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}
