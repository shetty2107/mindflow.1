"use client"

import { Navbar } from "@/components/navbar"
import { useState } from "react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    setFormData({ name: "", email: "", message: "" })
  }

  return (
    <main>
      <Navbar />

      <section className="min-h-screen bg-gradient-to-b from-background to-slate-50 dark:to-slate-900 px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <div className="text-center space-y-6 mb-16 animate-slide-in-up">
            <h1 className="text-5xl md:text-6xl font-bold text-slate-950 dark:text-slate-50">Get in Touch</h1>
            <p className="text-xl text-slate-600 dark:text-slate-400">
              We'd love to hear from you. Send us a message and we'll respond as soon as possible.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-8 animate-slide-in-up">
              <div>
                <h3 className="text-lg font-semibold text-slate-950 dark:text-slate-50 mb-2">Address</h3>
                <p className="text-slate-600 dark:text-slate-400">123 Innovation Street, Tech City, TC 12345</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-950 dark:text-slate-50 mb-2">Email</h3>
                <p className="text-slate-600 dark:text-slate-400">hello@company.com</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-950 dark:text-slate-50 mb-2">Phone</h3>
                <p className="text-slate-600 dark:text-slate-400">+1 (555) 123-4567</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6 animate-slide-in-up">
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-6 py-3 bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-950 dark:text-slate-50 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all duration-300"
              />
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-6 py-3 bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-950 dark:text-slate-50 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all duration-300"
              />
              <textarea
                name="message"
                placeholder="Your Message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={5}
                className="w-full px-6 py-3 bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-950 dark:text-slate-50 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all duration-300 resize-none"
              />
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-lg hover:shadow-lg transition-all duration-300 hover:scale-105 active:scale-95"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>
    </main>
  )
}
